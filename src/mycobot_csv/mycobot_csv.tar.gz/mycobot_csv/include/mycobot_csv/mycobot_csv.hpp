/**
 * mycobot_csv.hpp — ros2_control SystemInterface (CSV / mode 9)
 *
 * STRICT MIRROR of simple_ng.c.
 *
 * Architectural rule for this file: every PDO struct, every CiA 402 constant,
 * every controlword value, every SDO write sequence — identical to simple_ng.c.
 * If you find a divergence, it's a bug.
 *
 * The ONLY new code (vs simple_ng.c) is the ros2_control plumbing:
 *   - SystemInterface lifecycle methods (on_init, on_activate, on_deactivate)
 *   - export_state_interfaces / export_command_interfaces
 *   - read() / write() called by ControllerManager at update_rate
 *
 * Verification protocol:
 *   Open simple_ng.c next to mycobot_csv.cpp. Diff line-by-line:
 *     - PDO struct layout         → identical
 *     - CW_*, SW_* constants      → identical
 *     - laifual_csv_config()      → identical body, now a static method
 *     - cia402_enable() logic     → identical
 *     - PDO priming counts        → identical (5 + 5 + 10)
 *     - Controlword sequence      → 0x06 → 0x07 → 0x0F (Shutdown / Switch On / Enable Op)
 *
 * If you can verify those, you can trust the bring-up code.
 *
 * Command interface: VELOCITY in rad/s. User publishes to
 * /forward_velocity_controller/commands; plugin converts rad/s → counts/sec
 * via counts_per_rad parameter and writes to 0x60FF (target_velocity) over PDO.
 */

#pragma once

#include "hardware_interface/system_interface.hpp"
#include "hardware_interface/types/hardware_interface_type_values.hpp"
#include "rclcpp/rclcpp.hpp"
#include "rclcpp_lifecycle/state.hpp"

#include <vector>
#include <string>
#include <cstdint>

extern "C" {
#include "soem/soem.h"
}

namespace mycobot_csv {

/* ---------- PDO structures (verbatim from simple_ng.c lines 22-38) ---------- */
typedef struct __attribute__((packed)) {
    uint16_t controlword;
    int32_t  target_velocity;   /* 0x60FF:00  Target Velocity 32-bit */
    uint16_t touch_probe_func;
    uint32_t physical_output;
} csv_rxpdo_t;  /* 12 bytes */

typedef struct __attribute__((packed)) {
    uint16_t statusword;
    int32_t  position_actual;
    int16_t  torque_actual;
    int32_t  following_error;
    uint16_t touch_probe_stat;
    int32_t  touch_probe_pos1;
    int32_t  touch_probe_pos2;
    uint32_t physical_inputs;
} csv_txpdo_t;  /* 26 bytes */

/* ---------- CiA 402 constants (verbatim from simple_ng.c lines 41-51) ---------- */
#define CW_SWITCH_ON        (1 << 0)
#define CW_ENABLE_VOLTAGE   (1 << 1)
#define CW_QUICK_STOP       (1 << 2)
#define CW_ENABLE_OPERATION (1 << 3)
#define CW_FAULT_RESET      (1 << 7)

#define SW_READY_TO_SWITCH_ON  0x0021
#define SW_SWITCHED_ON         0x0023
#define SW_OPERATION_ENABLED   0x0027
#define SW_FAULT               0x0008
#define SW_STATE_MASK          0x006F

/* ---------- Plugin class ---------- */
class MyCobotCSV : public hardware_interface::SystemInterface
{
public:
  hardware_interface::CallbackReturn on_init(
    const hardware_interface::HardwareInfo & info) override;

  hardware_interface::CallbackReturn on_activate(
    const rclcpp_lifecycle::State & previous_state) override;

  hardware_interface::CallbackReturn on_deactivate(
    const rclcpp_lifecycle::State & previous_state) override;

  std::vector<hardware_interface::StateInterface> export_state_interfaces() override;
  std::vector<hardware_interface::CommandInterface> export_command_interfaces() override;

  hardware_interface::return_type read(
    const rclcpp::Time & time, const rclcpp::Duration & period) override;

  hardware_interface::return_type write(
    const rclcpp::Time & time, const rclcpp::Duration & period) override;

private:
  /* ros2_control buffers (SI units) */
  std::vector<double> hw_positions_;        /* state:   position (rad)  */
  std::vector<double> hw_velocities_;       /* state:   velocity (rad/s) */
  std::vector<double> hw_velocity_commands_;/* command: velocity (rad/s) */

  /* per-joint hardware mapping */
  std::vector<int>     joint_to_slave_;
  std::vector<double>  counts_per_rad_;
  std::vector<int32_t> last_position_counts_;

  /* plugin-level config */
  std::string ifname_;
  size_t      n_joints_{0};

  /* SOEM state — same fields as simple_ng's Fieldbus struct */
  ecx_contextt context_;
  uint8_t      io_map_[4096]{};
  uint8_t      group_{0};
  bool         soem_running_{false};

  /* convenience pointers into the IO map */
  std::vector<csv_rxpdo_t *> rxpdo_;
  std::vector<csv_txpdo_t *> txpdo_;

  rclcpp::Logger logger_{rclcpp::get_logger("MyCobotCSV")};

  /* ---------- helpers (each maps to a function in simple_ng.c) ---------- */
  bool init_soem();                          /* ec_init + config_init + map */
  bool reach_safe_op();                      /* PRE_OP → SAFE_OP            */
  bool reach_operational();                  /* SAFE_OP → OP + priming      */
  bool enable_drive(int slave_idx);          /* simple_ng's cia402_enable() */
  void disable_drive(int slave_idx);
  void close_soem();
  int  fieldbus_roundtrip();                 /* simple_ng's fieldbus_roundtrip */

  static const char * cia402_state_str(uint16_t sw);

  /* PO2SOconfig hook — verbatim port of laifual_csv_config */
  static int slave_csv_config(ecx_contextt * context, uint16_t slave);
};

}  // namespace mycobot_csv
