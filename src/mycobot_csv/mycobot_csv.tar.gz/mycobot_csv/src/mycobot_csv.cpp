/**
 * mycobot_csv.cpp — strict mirror of simple_ng.c, wrapped as a ros2_control plugin.
 *
 * To verify equivalence with simple_ng.c, sections of code below are tagged
 * with their source line numbers like this:
 *
 *     // === simple_ng.c:107-254  laifual_csv_config ===
 *
 * Open simple_ng.c at the noted line numbers and confirm body equivalence.
 * Any divergence is either a bug or a documented architectural change (none
 * are intended).
 */

#include "mycobot_csv/mycobot_csv.hpp"
#include "pluginlib/class_list_macros.hpp"

#include <cmath>
#include <cstring>
#include <limits>

namespace mycobot_csv {

/* ============================================================================
 * === simple_ng.c:53-67  cia402_state_str  (verbatim) ===
 * ========================================================================== */
const char * MyCobotCSV::cia402_state_str(uint16_t sw)
{
    uint16_t masked = sw & SW_STATE_MASK;
    if ((masked & 0x004F) == 0x0040) return "NOT_READY_TO_SWITCH_ON";
    if ((masked & 0x006F) == 0x0060) return "SWITCH_ON_DISABLED";
    if ((masked & 0x006F) == SW_READY_TO_SWITCH_ON) return "READY_TO_SWITCH_ON";
    if ((masked & 0x006F) == SW_SWITCHED_ON)         return "SWITCHED_ON";
    if ((masked & 0x006F) == SW_OPERATION_ENABLED)   return "OPERATION_ENABLED";
    if ((masked & 0x006F) == 0x0007) return "QUICK_STOP_ACTIVE";
    if ((masked & 0x004F) == 0x000F) return "FAULT_REACTION_ACTIVE";
    if ((masked & 0x006F) == 0x0028) return "FAULT";
    if (sw & SW_FAULT) return "FAULT";
    return "UNKNOWN";
}

/* ============================================================================
 * === simple_ng.c:107-254  laifual_csv_config  (verbatim, error-checking only) ===
 *
 * The body below is identical in operation to simple_ng's laifual_csv_config.
 * The only changes are:
 *   - DBG() prints stripped (we trust the SDO write counts, since simple_ng
 *     verified them on this hardware). If something fails here we'll surface
 *     it as a return -1.
 *   - readback verification SDOreads stripped for the same reason.
 * Every SDO WRITE matches simple_ng exactly: same object, same subindex,
 * same value, same order.
 * ========================================================================== */
int MyCobotCSV::slave_csv_config(ecx_contextt * context, uint16_t slave)
{
    int wc;
    uint8_t zero = 0;

    /* Step 1: Set CSV mode (0x6060 = 9)              [simple_ng.c:114-126] */
    int8_t mode = 9;
    wc = ecx_SDOwrite(context, slave, 0x6060, 0x00, FALSE,
                      sizeof(mode), &mode, EC_TIMEOUTSAFE);
    if (wc <= 0) return -1;
    osal_usleep(50000);

    int8_t mode_rb = 0;
    int sz = sizeof(mode_rb);
    ecx_SDOread(context, slave, 0x6060, 0x00, FALSE, &sz, &mode_rb, EC_TIMEOUTSAFE);
    if (mode_rb != 9) return -1;

    /* Step 2: Interpolation time (5ms)               [simple_ng.c:128-143] */
    int8_t interp_val = 5;
    int8_t interp_idx = -3;
    ecx_SDOwrite(context, slave, 0x60C2, 0x01, FALSE,
                 sizeof(interp_val), &interp_val, EC_TIMEOUTSAFE);
    ecx_SDOwrite(context, slave, 0x60C2, 0x02, FALSE,
                 sizeof(interp_idx), &interp_idx, EC_TIMEOUTSAFE);

    /* Step 3: Map TxPDO 0x1A02 — 26 bytes input      [simple_ng.c:145-174] */
    uint32_t tx_objs[] = {
        0x60410010,  /* Statusword       16-bit */
        0x60640020,  /* Position Actual  32-bit */
        0x60770010,  /* Torque Actual    16-bit */
        0x60F40020,  /* Following Error  32-bit */
        0x60B90010,  /* Touch Probe Stat 16-bit */
        0x60BA0020,  /* Touch Probe Pos1 32-bit */
        0x60BC0020,  /* Touch Probe Pos2 32-bit */
        0x60FD0020   /* Physical Inputs  32-bit */
    };
    const int tx_count = 8;

    ecx_SDOwrite(context, slave, 0x1A02, 0x00, FALSE,
                 sizeof(zero), &zero, EC_TIMEOUTSAFE);
    for (int i = 0; i < tx_count; i++) {
        wc = ecx_SDOwrite(context, slave, 0x1A02, i + 1, FALSE,
                          sizeof(tx_objs[i]), &tx_objs[i], EC_TIMEOUTSAFE);
        if (wc <= 0) return -1;
    }
    uint8_t eight = 8;
    ecx_SDOwrite(context, slave, 0x1A02, 0x00, FALSE,
                 sizeof(eight), &eight, EC_TIMEOUTSAFE);

    /* Step 4: Map RxPDO 0x1602 — 12 bytes output    [simple_ng.c:176-199] */
    uint32_t rx_objs[] = {
        0x60400010,  /* Controlword      16-bit */
        0x60FF0020,  /* Target Velocity  32-bit  (CSV) */
        0x60B80010,  /* Touch Probe Func 16-bit */
        0x60FE0120   /* Physical Output  32-bit  (subindex 0x01) */
    };
    const int rx_count = 4;

    ecx_SDOwrite(context, slave, 0x1602, 0x00, FALSE,
                 sizeof(zero), &zero, EC_TIMEOUTSAFE);
    for (int i = 0; i < rx_count; i++) {
        wc = ecx_SDOwrite(context, slave, 0x1602, i + 1, FALSE,
                          sizeof(rx_objs[i]), &rx_objs[i], EC_TIMEOUTSAFE);
        if (wc <= 0) return -1;
    }
    uint8_t four = 4;
    ecx_SDOwrite(context, slave, 0x1602, 0x00, FALSE,
                 sizeof(four), &four, EC_TIMEOUTSAFE);

    /* Step 4b: Output mask for brake (0x60FE:02)    [simple_ng.c:200-209] */
    uint32_t output_mask = 0x00000001;
    ecx_SDOwrite(context, slave, 0x60FE, 0x02, FALSE,
                 sizeof(output_mask), &output_mask, EC_TIMEOUTSAFE);

    /* Step 5: Assign SyncManagers                   [simple_ng.c:210-235] */
    uint16_t rx_map = 0x1602;
    uint16_t tx_map = 0x1A02;
    uint8_t  one    = 1;

    ecx_SDOwrite(context, slave, 0x1C12, 0x00, FALSE, sizeof(zero), &zero, EC_TIMEOUTSAFE);
    ecx_SDOwrite(context, slave, 0x1C12, 0x01, FALSE, sizeof(rx_map), &rx_map, EC_TIMEOUTSAFE);
    ecx_SDOwrite(context, slave, 0x1C12, 0x00, FALSE, sizeof(one), &one, EC_TIMEOUTSAFE);

    ecx_SDOwrite(context, slave, 0x1C13, 0x00, FALSE, sizeof(zero), &zero, EC_TIMEOUTSAFE);
    ecx_SDOwrite(context, slave, 0x1C13, 0x01, FALSE, sizeof(tx_map), &tx_map, EC_TIMEOUTSAFE);
    ecx_SDOwrite(context, slave, 0x1C13, 0x00, FALSE, sizeof(one), &one, EC_TIMEOUTSAFE);

    /* Step 6: Free-run sync mode                    [simple_ng.c:237-250] */
    uint16_t sync_free = 0;
    ecx_SDOwrite(context, slave, 0x1C32, 0x01, FALSE,
                 sizeof(sync_free), &sync_free, EC_TIMEOUTSAFE);
    ecx_SDOwrite(context, slave, 0x1C33, 0x01, FALSE,
                 sizeof(sync_free), &sync_free, EC_TIMEOUTSAFE);

    return 1;
}

/* ============================================================================
 * === simple_ng.c:88-102  fieldbus_roundtrip  (verbatim) ===
 * ========================================================================== */
int MyCobotCSV::fieldbus_roundtrip()
{
    ecx_send_processdata(&context_);
    return ecx_receive_processdata(&context_, 10000);
}

/* ============================================================================
 * === simple_ng.c:257-380  fieldbus_start (init + map + SAFE_OP only) ===
 *
 * NOTE: simple_ng's fieldbus_start does TWO things (reach SAFE_OP, then
 * reach OPERATIONAL after priming PDOs). For clarity we split them across
 * init_soem() / reach_safe_op() / reach_operational().
 * ========================================================================== */
bool MyCobotCSV::init_soem()
{
    std::memset(&context_, 0, sizeof(context_));
    std::memset(io_map_, 0, sizeof(io_map_));

    RCLCPP_INFO(logger_, "ec_init on '%s'...", ifname_.c_str());
    if (!ecx_init(&context_, ifname_.c_str())) {
        RCLCPP_ERROR(logger_,
            "ec_init failed on '%s'. Check interface name and CAP_NET_RAW.",
            ifname_.c_str());
        return false;
    }

    if (ecx_config_init(&context_) <= 0) {
        RCLCPP_ERROR(logger_, "No EtherCAT slaves found on '%s'.", ifname_.c_str());
        ecx_close(&context_);
        return false;
    }
    RCLCPP_INFO(logger_, "Found %d slave(s).", context_.slavecount);

    /* Attach PO2SOconfig (mirrors simple_ng.c:277) */
    for (size_t i = 0; i < n_joints_; ++i) {
        int s = joint_to_slave_[i];
        if (s < 1 || s > context_.slavecount) {
            RCLCPP_ERROR(logger_,
                "Joint '%s' references slave %d but bus has %d slaves.",
                info_.joints[i].name.c_str(), s, context_.slavecount);
            ecx_close(&context_);
            return false;
        }
        context_.slavelist[s].PO2SOconfig = &MyCobotCSV::slave_csv_config;
    }

    ecx_config_map_group(&context_, io_map_, group_);

    /* Disable SM watchdog (mirrors simple_ng.c:282-286) */
    for (size_t i = 0; i < n_joints_; ++i) {
        int s = joint_to_slave_[i];
        uint16_t wd_off = 0;
        ecx_FPWR(&context_.port, context_.slavelist[s].configadr,
                 0x0422, sizeof(wd_off), &wd_off, EC_TIMEOUTRET);
    }

    /* Verify PDO sizes match struct sizes (mirrors simple_ng.c:288-304) */
    ec_groupt * grp = context_.grouplist + group_;
    if (grp->Obytes != sizeof(csv_rxpdo_t)) {
        RCLCPP_ERROR(logger_,
            "Output PDO size mismatch: mapped %d bytes, expected %zu (csv_rxpdo_t).",
            grp->Obytes, sizeof(csv_rxpdo_t));
        ecx_close(&context_);
        return false;
    }
    if (grp->Ibytes != sizeof(csv_txpdo_t)) {
        RCLCPP_ERROR(logger_,
            "Input PDO size mismatch: mapped %d bytes, expected %zu (csv_txpdo_t).",
            grp->Ibytes, sizeof(csv_txpdo_t));
        ecx_close(&context_);
        return false;
    }

    /* Cache PDO pointers (mirrors simple_ng.c:382-383) */
    for (size_t i = 0; i < n_joints_; ++i) {
        int s = joint_to_slave_[i];
        rxpdo_[s] = reinterpret_cast<csv_rxpdo_t *>(context_.slavelist[s].outputs);
        txpdo_[s] = reinterpret_cast<csv_txpdo_t *>(context_.slavelist[s].inputs);
        if (!rxpdo_[s] || !txpdo_[s]) {
            RCLCPP_ERROR(logger_, "Slave %d: null PDO buffer after mapping.", s);
            ecx_close(&context_);
            return false;
        }
    }

    return true;
}

/* === simple_ng.c:348-378  request SAFE_OP === */
bool MyCobotCSV::reach_safe_op()
{
    context_.slavelist[0].state = EC_STATE_SAFE_OP;
    ecx_writestate(&context_, 0);

    for (int i = 0; i < 20; ++i) {
        ecx_statecheck(&context_, 0, EC_STATE_SAFE_OP, EC_TIMEOUTSTATE);
        ecx_readstate(&context_);
        if (context_.slavelist[0].state >= EC_STATE_SAFE_OP) return true;
        for (int s = 1; s <= context_.slavecount; ++s) {
            if (context_.slavelist[s].state == (EC_STATE_SAFE_OP + EC_STATE_ERROR) ||
                context_.slavelist[s].state == (EC_STATE_PRE_OP  + EC_STATE_ERROR)) {
                context_.slavelist[s].state =
                    (context_.slavelist[s].state & 0x0F) + EC_STATE_ACK;
                ecx_writestate(&context_, s);
                osal_usleep(100000);
            }
        }
    }
    return context_.slavelist[0].state >= EC_STATE_SAFE_OP;
}

/* === simple_ng.c:381-433  prime PDOs + request OPERATIONAL === */
bool MyCobotCSV::reach_operational()
{
    /* Prime rxpdo with safe values BEFORE going to OP
       (mirrors simple_ng.c:395-401 exactly: 5+10 roundtrips = 15 cycles) */
    for (size_t i = 0; i < n_joints_; ++i) {
        int s = joint_to_slave_[i];
        rxpdo_[s]->controlword      = CW_QUICK_STOP | CW_ENABLE_VOLTAGE;
        rxpdo_[s]->target_velocity  = 0;
        rxpdo_[s]->touch_probe_func = 0;
        rxpdo_[s]->physical_output  = 0;
    }
    for (int i = 0; i < 5; ++i) fieldbus_roundtrip();   /* simple_ng.c:385 */
    for (int i = 0; i < 10; ++i) fieldbus_roundtrip();  /* simple_ng.c:401 */

    /* Request OPERATIONAL */
    context_.slavelist[0].state = EC_STATE_OPERATIONAL;
    ecx_writestate(&context_, 0);

    for (int i = 0; i < 40; ++i) {
        fieldbus_roundtrip();
        ecx_statecheck(&context_, 0, EC_STATE_OPERATIONAL, EC_TIMEOUTSTATE / 10);
        ecx_readstate(&context_);
        bool all_op = true;
        for (size_t j = 0; j < n_joints_; ++j) {
            if (context_.slavelist[joint_to_slave_[j]].state != EC_STATE_OPERATIONAL) {
                all_op = false;
                break;
            }
        }
        if (all_op) return true;
    }
    return false;
}

/* ============================================================================
 * === simple_ng.c:446-517  cia402_enable  (verbatim logic) ===
 * ========================================================================== */
bool MyCobotCSV::enable_drive(int s)
{
    uint16_t sw;
    int timeout;

    fieldbus_roundtrip();
    sw = txpdo_[s]->statusword;
    RCLCPP_INFO(logger_, "Slave %d enable entry: sw=0x%04X (%s)",
                s, sw, cia402_state_str(sw));

    /* Fault reset (mirrors simple_ng.c:455-469) */
    if (sw & SW_FAULT) {
        rxpdo_[s]->controlword = CW_FAULT_RESET;
        for (timeout = 0; timeout < 100; ++timeout) {
            fieldbus_roundtrip();
            sw = txpdo_[s]->statusword;
            if (!(sw & SW_FAULT)) break;
            osal_usleep(5000);
        }
        if (sw & SW_FAULT) {
            RCLCPP_ERROR(logger_, "Slave %d: fault would not clear (sw=0x%04X)", s, sw);
            return false;
        }
    }

    /* Shutdown → READY_TO_SWITCH_ON  (CW=0x0006)  (simple_ng.c:471-483) */
    rxpdo_[s]->controlword = CW_QUICK_STOP | CW_ENABLE_VOLTAGE;
    for (timeout = 0; timeout < 200; ++timeout) {
        fieldbus_roundtrip();
        sw = txpdo_[s]->statusword;
        if ((sw & SW_STATE_MASK) == SW_READY_TO_SWITCH_ON) break;
        osal_usleep(5000);
    }
    if ((sw & SW_STATE_MASK) != SW_READY_TO_SWITCH_ON) {
        RCLCPP_ERROR(logger_, "Slave %d: failed Shutdown (sw=0x%04X / %s)",
                     s, sw, cia402_state_str(sw));
        return false;
    }

    /* Switch On → SWITCHED_ON  (CW=0x0007)  (simple_ng.c:485-497) */
    rxpdo_[s]->controlword = CW_QUICK_STOP | CW_ENABLE_VOLTAGE | CW_SWITCH_ON;
    for (timeout = 0; timeout < 200; ++timeout) {
        fieldbus_roundtrip();
        sw = txpdo_[s]->statusword;
        if ((sw & SW_STATE_MASK) == SW_SWITCHED_ON) break;
        osal_usleep(5000);
    }
    if ((sw & SW_STATE_MASK) != SW_SWITCHED_ON) {
        RCLCPP_ERROR(logger_, "Slave %d: failed Switch On (sw=0x%04X / %s)",
                     s, sw, cia402_state_str(sw));
        return false;
    }

    /* Enable Operation → OPERATION_ENABLED  (CW=0x000F)  (simple_ng.c:499-512) */
    rxpdo_[s]->controlword = CW_QUICK_STOP | CW_ENABLE_VOLTAGE
                           | CW_SWITCH_ON  | CW_ENABLE_OPERATION;
    for (timeout = 0; timeout < 200; ++timeout) {
        fieldbus_roundtrip();
        sw = txpdo_[s]->statusword;
        if ((sw & SW_STATE_MASK) == SW_OPERATION_ENABLED) break;
        osal_usleep(5000);
    }
    if ((sw & SW_STATE_MASK) != SW_OPERATION_ENABLED) {
        RCLCPP_ERROR(logger_, "Slave %d: failed Enable Operation (sw=0x%04X / %s)",
                     s, sw, cia402_state_str(sw));
        return false;
    }

    /* Brake release: stream PDOs for ~100 ms (mirrors simple_ng.c:603-615) */
    for (int i = 0; i < 20; ++i) {
        rxpdo_[s]->controlword     = CW_QUICK_STOP | CW_ENABLE_VOLTAGE
                                   | CW_SWITCH_ON  | CW_ENABLE_OPERATION;
        rxpdo_[s]->target_velocity = 0;
        rxpdo_[s]->physical_output = 0x00000001;
        fieldbus_roundtrip();
        osal_usleep(5000);
    }

    RCLCPP_INFO(logger_,
        "Slave %d: OPERATION_ENABLED, brake released. position_actual=%d",
        s, txpdo_[s]->position_actual);
    return true;
}

void MyCobotCSV::disable_drive(int s)
{
    if (!txpdo_[s] || !rxpdo_[s]) return;

    /* Mirrors simple_ng.c:697-710 */
    rxpdo_[s]->target_velocity = 0;
    rxpdo_[s]->controlword     = CW_QUICK_STOP | CW_ENABLE_VOLTAGE
                               | CW_SWITCH_ON  | CW_ENABLE_OPERATION;
    rxpdo_[s]->physical_output = 0x00000001;
    fieldbus_roundtrip();
    osal_usleep(50000);

    /* Re-engage brake */
    rxpdo_[s]->physical_output = 0;
    rxpdo_[s]->controlword     = CW_QUICK_STOP | CW_ENABLE_VOLTAGE;
    fieldbus_roundtrip();
    fieldbus_roundtrip();
    osal_usleep(50000);
}

void MyCobotCSV::close_soem()
{
    if (!soem_running_) return;
    context_.slavelist[0].state = EC_STATE_INIT;
    ecx_writestate(&context_, 0);
    ecx_close(&context_);
    soem_running_ = false;
    RCLCPP_INFO(logger_, "EtherCAT socket closed.");
}

/* ============================================================================
 * ros2_control SystemInterface lifecycle methods
 * (these are NEW vs simple_ng — the ros2_control wrapping)
 * ========================================================================== */
hardware_interface::CallbackReturn MyCobotCSV::on_init(
    const hardware_interface::HardwareInfo & info)
{
    if (hardware_interface::SystemInterface::on_init(info) !=
        hardware_interface::CallbackReturn::SUCCESS) {
        return hardware_interface::CallbackReturn::ERROR;
    }

    auto it = info_.hardware_parameters.find("ifname");
    if (it == info_.hardware_parameters.end()) {
        RCLCPP_ERROR(logger_, "Missing required <param name=\"ifname\"> in URDF.");
        return hardware_interface::CallbackReturn::ERROR;
    }
    ifname_ = it->second;

    n_joints_ = info_.joints.size();
    hw_positions_.assign(n_joints_, 0.0);
    hw_velocities_.assign(n_joints_, 0.0);
    hw_velocity_commands_.assign(n_joints_, std::numeric_limits<double>::quiet_NaN());
    joint_to_slave_.assign(n_joints_, 0);
    counts_per_rad_.assign(n_joints_, 0.0);
    last_position_counts_.assign(n_joints_, 0);

    int max_slave = 0;
    for (size_t i = 0; i < n_joints_; ++i) {
        const auto & j = info_.joints[i];

        auto it_s = j.parameters.find("slave_index");
        auto it_c = j.parameters.find("counts_per_rad");
        if (it_s == j.parameters.end() || it_c == j.parameters.end()) {
            RCLCPP_ERROR(logger_,
                "Joint '%s' is missing required <param>: slave_index AND counts_per_rad",
                j.name.c_str());
            return hardware_interface::CallbackReturn::ERROR;
        }
        joint_to_slave_[i] = std::stoi(it_s->second);
        counts_per_rad_[i] = std::stod(it_c->second);
        if (joint_to_slave_[i] > max_slave) max_slave = joint_to_slave_[i];

        bool has_vel_cmd = false;
        for (const auto & ci : j.command_interfaces) {
            if (ci.name == hardware_interface::HW_IF_VELOCITY) has_vel_cmd = true;
        }
        if (!has_vel_cmd) {
            RCLCPP_ERROR(logger_,
                "Joint '%s' must declare a 'velocity' command interface (CSV mode).",
                j.name.c_str());
            return hardware_interface::CallbackReturn::ERROR;
        }
    }

    rxpdo_.assign(max_slave + 1, nullptr);
    txpdo_.assign(max_slave + 1, nullptr);

    RCLCPP_INFO(logger_,
        "MyCobotCSV initialised: ifname='%s', %zu joint(s), max slave %d.",
        ifname_.c_str(), n_joints_, max_slave);

    return hardware_interface::CallbackReturn::SUCCESS;
}

std::vector<hardware_interface::StateInterface>
MyCobotCSV::export_state_interfaces()
{
    std::vector<hardware_interface::StateInterface> ifaces;
    for (size_t i = 0; i < n_joints_; ++i) {
        ifaces.emplace_back(info_.joints[i].name,
                            hardware_interface::HW_IF_POSITION, &hw_positions_[i]);
        ifaces.emplace_back(info_.joints[i].name,
                            hardware_interface::HW_IF_VELOCITY, &hw_velocities_[i]);
    }
    return ifaces;
}

std::vector<hardware_interface::CommandInterface>
MyCobotCSV::export_command_interfaces()
{
    std::vector<hardware_interface::CommandInterface> ifaces;
    for (size_t i = 0; i < n_joints_; ++i) {
        ifaces.emplace_back(info_.joints[i].name,
                            hardware_interface::HW_IF_VELOCITY,
                            &hw_velocity_commands_[i]);
    }
    return ifaces;
}

hardware_interface::CallbackReturn MyCobotCSV::on_activate(
    const rclcpp_lifecycle::State & /*previous_state*/)
{
    RCLCPP_INFO(logger_, "Activating MyCobotCSV...");

    if (!init_soem()) return hardware_interface::CallbackReturn::ERROR;
    soem_running_ = true;

    if (!reach_safe_op()) {
        RCLCPP_ERROR(logger_, "Failed to reach SAFE_OP.");
        close_soem();
        return hardware_interface::CallbackReturn::ERROR;
    }

    if (!reach_operational()) {
        RCLCPP_ERROR(logger_, "Failed to reach OPERATIONAL.");
        close_soem();
        return hardware_interface::CallbackReturn::ERROR;
    }

    for (size_t i = 0; i < n_joints_; ++i) {
        int s = joint_to_slave_[i];
        if (!enable_drive(s)) {
            RCLCPP_ERROR(logger_, "Drive enable failed for joint '%s' (slave %d).",
                         info_.joints[i].name.c_str(), s);
            close_soem();
            return hardware_interface::CallbackReturn::ERROR;
        }
    }

    /* Seed buffers from live PDO state — first cycle won't see NaN */
    for (size_t i = 0; i < n_joints_; ++i) {
        int s = joint_to_slave_[i];
        int32_t cnt = txpdo_[s]->position_actual;
        last_position_counts_[i]  = cnt;
        hw_positions_[i]          = static_cast<double>(cnt) / counts_per_rad_[i];
        hw_velocities_[i]         = 0.0;
        hw_velocity_commands_[i]  = 0.0;
    }

    RCLCPP_INFO(logger_, "MyCobotCSV ACTIVE — %zu drive(s) operating.", n_joints_);
    return hardware_interface::CallbackReturn::SUCCESS;
}

hardware_interface::CallbackReturn MyCobotCSV::on_deactivate(
    const rclcpp_lifecycle::State & /*previous_state*/)
{
    RCLCPP_INFO(logger_, "Deactivating MyCobotCSV...");
    for (size_t i = 0; i < n_joints_; ++i) {
        disable_drive(joint_to_slave_[i]);
    }
    close_soem();
    return hardware_interface::CallbackReturn::SUCCESS;
}

/* read() — copy fresh feedback from txpdo into ros2_control state buffers */
hardware_interface::return_type MyCobotCSV::read(
    const rclcpp::Time & /*time*/, const rclcpp::Duration & period)
{
    const double dt = period.seconds() > 1e-6 ? period.seconds() : 0.005;

    for (size_t i = 0; i < n_joints_; ++i) {
        int s = joint_to_slave_[i];
        int32_t cnt = txpdo_[s]->position_actual;

        hw_positions_[i]  = static_cast<double>(cnt) / counts_per_rad_[i];
        hw_velocities_[i] =
            (static_cast<double>(cnt - last_position_counts_[i]) / counts_per_rad_[i]) / dt;
        last_position_counts_[i] = cnt;
    }
    return hardware_interface::return_type::OK;
}

/* write() — stage commands and exchange one PDO frame
 *
 * The body below is the steady-state per-cycle work, equivalent to one
 * iteration of simple_ng's main loop (lines 642-695). Only difference:
 * target_velocity comes from hw_velocity_commands_ (rad/s, scaled by
 * counts_per_rad) rather than a hardcoded constant. */
hardware_interface::return_type MyCobotCSV::write(
    const rclcpp::Time & /*time*/, const rclcpp::Duration & /*period*/)
{
    for (size_t i = 0; i < n_joints_; ++i) {
        int s = joint_to_slave_[i];

        /* Defensive: hold-zero if controller hasn't published yet */
        double cmd_rad_per_sec = hw_velocity_commands_[i];
        if (!std::isfinite(cmd_rad_per_sec)) cmd_rad_per_sec = 0.0;

        int32_t cnt_per_sec = static_cast<int32_t>(
            std::lround(cmd_rad_per_sec * counts_per_rad_[i]));

        rxpdo_[s]->target_velocity  = cnt_per_sec;
        rxpdo_[s]->controlword      = CW_QUICK_STOP | CW_ENABLE_VOLTAGE
                                    | CW_SWITCH_ON  | CW_ENABLE_OPERATION;
        rxpdo_[s]->physical_output  = 0x00000001;   /* brake released */
        rxpdo_[s]->touch_probe_func = 0;
    }

    int wkc = fieldbus_roundtrip();
    if (wkc <= 0) {
        static rclcpp::Clock throttle_clock(RCL_STEADY_TIME);
        RCLCPP_WARN_THROTTLE(logger_, throttle_clock, 1000,
            "PDO roundtrip wkc=%d (link issue?).", wkc);
    }
    return hardware_interface::return_type::OK;
}

}  // namespace mycobot_csv

PLUGINLIB_EXPORT_CLASS(mycobot_csv::MyCobotCSV,
                       hardware_interface::SystemInterface)
